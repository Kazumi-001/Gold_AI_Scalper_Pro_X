#!/usr/bin/env bash
set -euo pipefail

repo_root="${1:-.}"
cd "$repo_root"

patch_file="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/Build_1.0.019.patch"
notes_file="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/RELEASE_NOTES_1.0.019.md"

git apply --check "$patch_file"
git apply "$patch_file"
cp "$notes_file" ./RELEASE_NOTES_1.0.019.md

git diff --check

echo "Build 1.0.019 patch applied successfully."
echo "Review with: git diff"
echo "Commit with: git add . && git commit -m 'Build 1.0.019: add adaptive entry score'"
