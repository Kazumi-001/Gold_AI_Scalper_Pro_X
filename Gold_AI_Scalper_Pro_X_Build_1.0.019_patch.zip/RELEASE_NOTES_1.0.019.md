# Build 1.0.019 — Adaptive Entry Score

## Baseline

Build 1.0.019 returns to the Build 1.0.015 behavior for position cap, average-price
ATR stop, grid management and entry timing. The rejected 30-minute loss cooldown
is disabled by default.

## Single experiment

The only strategy experiment is a consecutive-loss score penalty:

- 0 consecutive losses: required score = 80
- 1 consecutive loss: required score = 85
- 2 or more consecutive losses: required score = 90
- A profitable completed basket resets the consecutive-loss count to zero.

Signals that meet the original score of 80 but do not meet the adaptive score are
logged as `ADAPTIVE_ENTRY_BLOCK`.

## June acceptance test

Use:

- Symbol: `GOLD#`
- Timeframe: M1
- Period: `2026.06.01` through `2026.06.30`
- Spread: 30
- `InpSimulationMode=true`
- `InpMaxPositions=3`
- `InpLossCooldownMinutes=0`
- `InpAdaptiveEntryScore=true`
- `InpLossPenalty1=5`
- `InpLossPenalty2=10`

Verify the CSV header contains:

```text
test=POSITION_CAP,result=PASS,details=3
test=LOSS_COOLDOWN_DISABLED,result=PASS,details=0
test=ENTRY_SCORE_ADAPTIVE,result=PASS,details=80/5/10
```

Compare net result, profit factor, maximum equity drawdown and completed basket
count against Build 1.0.015.
