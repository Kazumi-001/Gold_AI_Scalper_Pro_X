# Build 1.0.019 — Adaptive Entry Score

## Single experiment

Build 1.0.019 keeps the Build 1.0.015 position cap, average-price ATR stop, grid logic and risk controls. The rejected 30-minute post-loss cooldown is disabled.

The required signal score becomes:

- 0 consecutive losses: 80
- 1 consecutive loss: 85
- 2 or more consecutive losses: 90

A profitable completed basket resets the consecutive-loss count. Blocked signals are logged as `ADAPTIVE_ENTRY_BLOCK`.

## June acceptance test

- Symbol: `GOLD#`
- Timeframe: M1
- Period: `2026.06.01` through `2026.06.30`
- Spread: 30
- Simulation Mode: true

Verify:

```text
test=POSITION_CAP,result=PASS,details=3
test=LOSS_COOLDOWN_DISABLED,result=PASS,details=0
test=ENTRY_SCORE_ADAPTIVE,result=PASS,details=80/5/10
```

Compare net result, PF, maximum equity DD and completed baskets with Build 1.0.015.
